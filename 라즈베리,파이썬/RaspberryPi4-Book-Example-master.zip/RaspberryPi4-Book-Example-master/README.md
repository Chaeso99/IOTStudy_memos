# IoT 사물인터넷을 위한 라즈베리파이 4 정석

- <http://jspstudy.co.kr>

- <https://blog.naver.com/codingspecialist>

- <https://blog.naver.com/getinthere>

![blog](http://image.yes24.com/Goods/83492347/800x0)
