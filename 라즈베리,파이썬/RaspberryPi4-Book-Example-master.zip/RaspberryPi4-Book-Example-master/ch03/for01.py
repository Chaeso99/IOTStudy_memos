for i in range(0, 5, 1):
    print(i)
print("----------")
for j in[1,3,5,7,9]:
    print(j)    
print("----------")
for k in range(0, 3, 1):
     print("꿈은 이루어 진다.")   
