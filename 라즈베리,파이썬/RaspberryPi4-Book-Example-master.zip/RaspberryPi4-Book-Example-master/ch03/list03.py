aa =[]
aa.append(0)
aa.append(0)
aa.append(0)
aa.append(0)
print(len(aa))
print(aa)
bb = []
for i in range(0, 100):
    bb.append(i)
print(bb)  
