def mydef01():
    print("일반 함수입니다.")
def mydef02(n, m):
    print(n*m)