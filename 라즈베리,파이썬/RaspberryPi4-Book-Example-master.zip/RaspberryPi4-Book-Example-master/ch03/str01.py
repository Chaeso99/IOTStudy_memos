a = "파이썬 만세"
print(a)
print(type(a))
b = 'python go'
print(b)