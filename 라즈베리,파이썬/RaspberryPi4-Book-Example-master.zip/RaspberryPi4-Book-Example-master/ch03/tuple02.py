one = '하나'
print(type(one))
one = "원"
print(one)
two = '둘'
print(type(two))
#two[0] = '투'
print(two[0])
