#정육각형 그리기

import turtle

t = turtle.Turtle()
t.shape("turtle")
t.forward(100)
t.left(60)
t.forward(100)
t.left(60)
t.forward(100)
t.left(60)
t.forward(100)
t.left(60)
t.forward(100)
t.left(60)
t.forward(100)
