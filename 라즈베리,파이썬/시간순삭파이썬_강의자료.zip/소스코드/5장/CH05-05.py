#CH05-05 if를 좀 더 이해시켜 줄 예제

language = int(input("언어를 선택하세요(1=한국어, 2=영어, 3=프랑스어, 4=독일어)"))

if language == 1 :	# 콜론(:)을 잊지 마세요.
    print("안녕")

if language == 2 :
    print("Hello")

if language == 3 :
    print("Bonjour")

if language == 4 :
    print("Guten morgen")
