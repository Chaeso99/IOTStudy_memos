#CH06-05. 조건 제어 반복-while

response = "아니"
while response == "아니":
    response = input("엄마, 다됐어? ");
print("먹자")
