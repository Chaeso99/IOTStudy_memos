#CH06-09. break 와 continue

##################################################################
##continue 프로그램
for n in range(10) :
    if n % 2 == 0 :
       continue
    print(n)
