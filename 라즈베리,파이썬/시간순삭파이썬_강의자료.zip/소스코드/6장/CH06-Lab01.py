#CH06-Lab01 코드를 줄여보아요.

import turtle
t = turtle.Turtle()	
for count in range(6):
    t.circle(100)
    t.left(360/6)
