#CH06-Lab09 별 그리는 터틀

import turtle
t = turtle.Turtle()
t.color("blue")
t.shape("turtle")

i = 0
while i < 5:
    t.forward(50)
    t.right(144)
    i = i + 1
