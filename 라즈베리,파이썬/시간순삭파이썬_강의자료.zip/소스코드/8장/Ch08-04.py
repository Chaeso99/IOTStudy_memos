#CH08-04. 함수에 1개의 인수 전달하기

##################################################################
##우편물을 받는 사람의 주소를 인쇄하는 print_address( ) 함수가 있는 프로그램

def print_address(name):
    print("서울특별시 종로구 1번지")
    print("파이썬 빌딩 7층")
    print(name)

print_address("홍길동")
print_address("김코드")
print_address("나함수")
