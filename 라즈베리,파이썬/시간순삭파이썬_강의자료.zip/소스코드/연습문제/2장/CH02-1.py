n1 = int(input("첫 번째 숫자를 입력하시오: "))
n2 = int(input("두 번째 숫자를 입력하시오: "))
n3 = int(input("세 번째 숫자를 입력하시오: "))

average = (n1 + n2 + n3) / 3

print(n1, n2, n3,"의 평균은", average, "입니다.")
