r = float(input("r: "))
h = float(input("h: "))

vol = 3.141592*r**2 * h
print("원기둥의 부피: ", vol)
