age = 20
if age < 20:
    print('20살 미만')
elif age >= 30 and age <= 50:
    print('30살 이상이고 50살 이하')
else:
    print('20살 이상이고 30살 미만')
