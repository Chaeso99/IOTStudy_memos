ans = 0
while ans != 3*9:
    ans = int(input("3*9 = "))
print("맞았습니다.")
